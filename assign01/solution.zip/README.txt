Team: Esther Kwon and Emily Guan
Esther: uint256_create_from_u64 and uint256_get_bits
Emily: uint256_create